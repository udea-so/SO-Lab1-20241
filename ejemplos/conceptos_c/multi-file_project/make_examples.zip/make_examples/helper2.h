#ifndef HELPER2_H
#define HELPER2_H

extern int num; // num se definio en helper1.c

void incrementar_num2(int);
void obtener_hora_actual(void);

#endif //HELPER2_H
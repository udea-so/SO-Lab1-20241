#ifndef HELPER1_H
#define HELPER1_H

extern int num; // num se definio en helper1.c

void saludo(void);
void incrementar_num(void);
int tam(const char *);

#endif //HELPER1_H

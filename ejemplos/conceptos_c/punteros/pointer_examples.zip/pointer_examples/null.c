#include <stdio.h>

int main()
{
    int *p = NULL;
    *p = 10;
    return 0;
}
